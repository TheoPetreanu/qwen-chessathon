"""AI Chessathon agent.

    get_move(fen, time_left_ms) -> UCI string

Everything expensive happens at import: numba compiles the whole search and we
warm every jitted function on a real position, so the first competition move is
charged only for thinking, not for compiling. The rules give 90 s of free init
for exactly this.

python-chess appears in two places only: parsing the FEN we are handed, and a
final legality check on the move we are about to return. It is never used
inside the search.
"""
import sys
import time

_T0 = time.time()

import numpy as np
import chess

from ca_movegen import gen_moves, make_move, unmake_move, in_check
from ca_position import (new_position, new_stacks, from_board, move_to_uci,
                         MAX_PLY)
from ca_search import (search_root, new_tt, new_heuristics, MATE, MATE_IN_MAX)

# --- persistent state (the process survives between our own moves) ----------
_BB, _OCC, _MAIL, _ST, _HSH = new_position()
_UNDO, _UNDO_H, _MOVES = new_stacks()
_MSCORES = np.zeros((MAX_PLY + 8, 256), dtype=np.int64)
_TT_KEY, _TT_DATA = new_tt()
_KILLERS, _HISTORY, _COUNTER = new_heuristics()
_REP = np.zeros(2048, dtype=np.uint64)
_INFO = np.zeros(8, dtype=np.int64)
_CTRL = np.zeros(2, dtype=np.float64)

# Hashes of every position we have been asked about, so we can avoid walking
# into a repetition the referee would claim as a draw.
_SEEN = []
_MOVE_NUMBER = 0

MOVE_OVERHEAD_MS = 70.0      # safety margin for interprocess handoff
DEFAULT_INC_MS = 500.0       # competition increment; refined by observation
MOVES_TO_GO = 28             # how many more moves we budget for. Self-play from
                             # tests/openings.py balanced starts averages ~50
                             # full moves per game (median 54, range 24-84; see
                             # tools/measure_game_lengths.py), which argues for
                             # raising this. Tried 45: +29 Elo +/- 81 at fast TC,
                             # +14 Elo +/- 64 at the real TC (both gauntlet.py,
                             # engine vs a MOVES_TO_GO=28 copy) -- both CIs cross
                             # zero, i.e. not a confirmed improvement, so left
                             # at the original value. See PROGRESS.md.
RESERVE_MS = 250.0           # never plan to go below this

_CLOCK_STATE = {"prev_left": None, "prev_spent": 0.0, "inc": DEFAULT_INC_MS}


def _observe_increment(time_left_ms):
    """Infer the real increment instead of trusting a constant.

    The clock we are handed at the start of our turn is
        previous_clock - what_we_spent + increment
    so one subtraction recovers the increment, and it also absorbs any
    referee-side overhead we are being charged for but cannot see.
    """
    st = _CLOCK_STATE
    prev = st["prev_left"]
    if prev is not None:
        observed = time_left_ms - (prev - st["prev_spent"])
        if 0.0 <= observed <= 10000.0:
            # smooth, so one noisy sample cannot swing the budget
            st["inc"] = 0.5 * st["inc"] + 0.5 * observed
    return st["inc"]


def _think_time(time_left_ms, n_legal, inc_ms=None):
    """Per-move budget.

    The one property that matters is that the engine can never flag: the
    steady-state spend must stay strictly below the increment, so as the base
    clock runs down the budget converges to something the increment pays for.
    A fixed floor larger than the increment (the earlier bug) drains the clock
    monotonically no matter how large the base is.
    """
    inc = _CLOCK_STATE["inc"] if inc_ms is None else inc_ms
    left = time_left_ms - MOVE_OVERHEAD_MS
    if left <= RESERVE_MS:
        return max(left * 0.25, 5.0), max(left * 0.4, 8.0)
    if n_legal <= 1:
        return min(30.0, left * 0.3), min(50.0, left * 0.4)

    usable = left - RESERVE_MS
    # 0.80 * increment is the steady-state floor, deliberately below the
    # increment itself so the clock recovers rather than bleeds
    soft = 0.80 * inc + usable / MOVES_TO_GO
    hard = min(soft * 2.5, usable * 0.20)

    # emergency: with only a few increments of slack left, live off the increment
    if left < 8.0 * inc + RESERVE_MS:
        soft = min(soft, 0.55 * inc + usable / 12.0)
        hard = min(soft * 1.6, usable * 0.5)
    if hard < soft:
        hard = soft
    return soft, hard


_LAST_PIECES = [0]


def _is_new_game(board):
    """The referee starts a fresh process per game, but never rely on that: if
    the piece count has gone UP since the last position we were asked about,
    this cannot be the same game, so the old history must not be reused."""
    n = len(board.piece_map())
    prev = _LAST_PIECES[0]
    _LAST_PIECES[0] = n
    return prev != 0 and n > prev


def _sync_position(board):
    from_board(board, _BB, _OCC, _MAIL, _ST, _HSH)


def _warmup():
    """Compile and exercise every jitted function during the free init window."""
    warm_positions = [
        chess.STARTING_FEN,
        "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
        "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
        "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
        "8/5k2/8/8/8/8/3K1P2/8 w - - 0 1",
    ]
    for fen in warm_positions:
        board = chess.Board(fen)
        _sync_position(board)
        _REP[0] = _HSH[0]
        _INFO[0] = 1
        _CTRL[0] = time.time() + 0.55
        _CTRL[1] = time.time() + 0.35
        search_root(_BB, _OCC, _MAIL, _ST, _HSH, _UNDO, _UNDO_H, _MOVES,
                    _MSCORES, _TT_KEY, _TT_DATA, _KILLERS, _HISTORY, _COUNTER,
                    _REP, 24, _INFO, _CTRL)
    # discard warm-up knowledge so it cannot bias the real game
    _TT_KEY[:] = 0
    _TT_DATA[:] = 0
    _HISTORY[:] = 0
    _COUNTER[:] = 0
    _KILLERS[:] = 0


def get_move(fen, time_left_ms):
    global _MOVE_NUMBER
    board = chess.Board(fen)
    legal = list(board.legal_moves)
    if not legal:
        return "0000"
    if len(legal) == 1:
        return legal[0].uci()

    _MOVE_NUMBER += 1
    _sync_position(board)

    # Rebuild the repetition history. We only ever see positions where it is
    # our turn, i.e. two plies apart, so a placeholder is written between them:
    # the search walks back in steps of two to find same-side-to-move positions,
    # and this keeps that stride landing on real keys.
    key = np.uint64(_HSH[0])
    if _is_new_game(board):
        del _SEEN[:]
    _SEEN.append(key)
    if len(_SEEN) > 400:
        del _SEEN[:-400]
    for i, k in enumerate(_SEEN):
        _REP[2 * i] = k
        if 2 * i + 1 < len(_REP):
            _REP[2 * i + 1] = np.uint64(0)
    _INFO[0] = 2 * len(_SEEN) - 1

    inc = _observe_increment(float(time_left_ms))
    soft, hard = _think_time(float(time_left_ms), len(legal), inc)
    now = time.time()
    _CTRL[0] = now + hard / 1000.0
    _CTRL[1] = now + soft / 1000.0

    search_root(_BB, _OCC, _MAIL, _ST, _HSH, _UNDO, _UNDO_H, _MOVES, _MSCORES,
                _TT_KEY, _TT_DATA, _KILLERS, _HISTORY, _COUNTER, _REP,
                MAX_PLY - 8, _INFO, _CTRL)

    _CLOCK_STATE["prev_left"] = float(time_left_ms)
    _CLOCK_STATE["prev_spent"] = (time.time() - now) * 1000.0

    uci = move_to_uci(np.int32(_INFO[4]))

    # Final safety net. A malformed or illegal move loses the game outright, so
    # verify against python-chess and fall back rather than ever returning one.
    try:
        mv = chess.Move.from_uci(uci)
    except ValueError:
        mv = None
    if mv is None or mv not in board.legal_moves:
        mv = _fallback(board, legal)
        uci = mv.uci()
    return uci


def _fallback(board, legal):
    """Something went wrong in the search. Pick the least bad legal move by a
    one-ply material count rather than returning a random one."""
    best, best_score = legal[0], -10 ** 9
    vals = {chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330,
            chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 0}
    for mv in legal:
        s = 0
        victim = board.piece_at(mv.to_square)
        if victim is not None:
            s += vals[victim.piece_type]
        if board.is_capture(mv) and board.is_attacked_by(not board.turn, mv.to_square):
            mover = board.piece_at(mv.from_square)
            if mover is not None:
                s -= vals[mover.piece_type]
        board.push(mv)
        if board.is_checkmate():
            s += 100000
        board.pop()
        if s > best_score:
            best, best_score = mv, s
    return best


_warmup()
INIT_SECONDS = time.time() - _T0
