"""Baseline opponent: a competent python-chess alpha-beta agent.

This is the shape of a good non-accelerated submission -- negamax with
alpha-beta, a transposition table, MVV-LVA ordering, killers, quiescence,
tapered piece-square evaluation and iterative deepening with time management.
It exists to measure how much the bitboard/numba core is actually worth, so it
is written to be decent rather than to be beaten.
"""
import time
import chess

MATE = 30000
PIECE_MG = {chess.PAWN: 85, chess.KNIGHT: 330, chess.BISHOP: 350,
            chess.ROOK: 480, chess.QUEEN: 1000, chess.KING: 0}
PIECE_EG = {chess.PAWN: 100, chess.KNIGHT: 290, chess.BISHOP: 310,
            chess.ROOK: 520, chess.QUEEN: 950, chess.KING: 0}
PHASE = {chess.PAWN: 0, chess.KNIGHT: 1, chess.BISHOP: 1,
         chess.ROOK: 2, chess.QUEEN: 4, chess.KING: 0}

_PST = {
    chess.PAWN: [0,0,0,0,0,0,0,0, 60,70,60,60,60,60,70,60, 15,20,30,40,40,30,20,15,
                 5,8,15,28,28,12,8,5, 0,2,8,22,22,5,2,0, 2,-2,2,8,10,0,-4,2,
                 2,5,5,-12,-12,8,8,2, 0,0,0,0,0,0,0,0],
    chess.KNIGHT: [-55,-40,-25,-20,-20,-25,-40,-55, -35,-15,5,8,8,5,-15,-35,
                   -20,8,22,28,28,22,8,-20, -15,10,26,32,32,26,10,-15,
                   -18,6,24,30,30,24,6,-18, -22,4,18,22,22,18,4,-22,
                   -35,-18,2,8,8,2,-18,-35, -58,-32,-22,-16,-16,-22,-32,-58],
    chess.BISHOP: [-18,-10,-12,-8,-8,-12,-10,-18, -10,4,0,2,2,0,4,-10,
                   -6,8,12,10,10,12,8,-6, -4,6,14,18,18,14,6,-4,
                   -4,8,14,18,18,14,8,-4, -2,14,14,12,12,14,14,-2,
                   -6,16,6,6,6,6,16,-6, -16,-6,-8,-12,-12,-8,-6,-16],
    chess.ROOK: [4,4,6,8,8,6,4,4, 14,18,20,22,22,20,18,14, -2,2,6,8,8,6,2,-2,
                 -6,-2,2,4,4,2,-2,-6, -8,-4,0,2,2,0,-4,-8, -10,-4,0,2,2,0,-4,-10,
                 -12,-4,0,4,4,0,-4,-12, -6,-4,4,10,10,4,-4,-6],
    chess.QUEEN: [-14,-8,-6,-2,-2,-6,-8,-14, -8,0,4,4,4,4,0,-8, -6,4,6,8,8,6,4,-6,
                  -2,4,8,10,10,8,4,-2, 0,6,8,10,10,8,6,0, -6,6,6,8,8,6,6,-6,
                  -8,0,6,4,4,6,0,-8, -14,-8,-6,0,0,-6,-8,-14],
    chess.KING: [-60,-70,-70,-80,-80,-70,-70,-60, -55,-62,-66,-74,-74,-66,-62,-55,
                 -45,-55,-60,-68,-68,-60,-55,-45, -38,-48,-54,-62,-62,-54,-48,-38,
                 -28,-36,-44,-52,-52,-44,-36,-28, -14,-24,-30,-34,-34,-30,-24,-14,
                 16,16,-6,-14,-14,-6,16,16, 22,32,8,-14,0,-16,30,20],
}
_KING_EG = [-72,-40,-22,-12,-12,-22,-40,-72, -30,-8,10,18,18,10,-8,-30,
            -14,14,30,36,36,30,14,-14, -12,18,36,44,44,36,18,-12,
            -14,16,34,42,42,34,16,-14, -18,10,24,30,30,24,10,-18,
            -30,-4,8,12,12,8,-4,-30, -58,-34,-20,-14,-14,-20,-34,-58]

def _flip(t):
    out = []
    for r in range(7, -1, -1):
        out.extend(t[r * 8:r * 8 + 8])
    return out

PST = {p: _flip(t) for p, t in _PST.items()}
KING_EG = _flip(_KING_EG)

TT = {}
_deadline = [0.0]
_nodes = [0]


class Timeout(Exception):
    pass


def evaluate(board):
    mg = eg = phase = 0
    for sq, pc in board.piece_map().items():
        rel = sq if pc.color == chess.WHITE else sq ^ 56
        s = 1 if pc.color == chess.WHITE else -1
        mg += s * (PIECE_MG[pc.piece_type] + PST[pc.piece_type][rel])
        eg += s * (PIECE_EG[pc.piece_type] +
                   (KING_EG[rel] if pc.piece_type == chess.KING
                    else PST[pc.piece_type][rel]))
        phase += PHASE[pc.piece_type]
    phase = min(phase, 24)
    score = (mg * phase + eg * (24 - phase)) // 24
    return score if board.turn == chess.WHITE else -score


VICT = {chess.PAWN: 100, chess.KNIGHT: 320, chess.BISHOP: 330,
        chess.ROOK: 500, chess.QUEEN: 900, chess.KING: 10000}


def order(board, moves, tt_move, killers, ply):
    def key(m):
        if m == tt_move:
            return 1 << 30
        if board.is_capture(m):
            victim = board.piece_at(m.to_square)
            v = VICT[victim.piece_type] if victim else 100
            a = board.piece_at(m.from_square)
            return 900000 + v * 16 - (VICT[a.piece_type] if a else 0)
        if m.promotion:
            return 800000 + m.promotion
        if ply < len(killers) and m in killers[ply]:
            return 700000
        return 0
    return sorted(moves, key=key, reverse=True)


def qsearch(board, alpha, beta, ply):
    _nodes[0] += 1
    if (_nodes[0] & 511) == 0 and time.time() > _deadline[0]:
        raise Timeout
    checked = board.is_check()
    if not checked:
        stand = evaluate(board)
        if stand >= beta:
            return stand
        alpha = max(alpha, stand)
        best = stand
    else:
        best = -MATE + ply
    moves = [m for m in board.legal_moves
             if checked or board.is_capture(m) or m.promotion]
    if not moves:
        if checked:
            return -MATE + ply
        return best
    for m in order(board, moves, None, [], ply):
        board.push(m)
        v = -qsearch(board, -beta, -alpha, ply + 1)
        board.pop()
        if v > best:
            best = v
            alpha = max(alpha, v)
            if v >= beta:
                break
    return best


def negamax(board, depth, alpha, beta, ply, killers):
    _nodes[0] += 1
    if (_nodes[0] & 511) == 0 and time.time() > _deadline[0]:
        raise Timeout
    if ply > 0 and (board.is_repetition(2) or board.halfmove_clock >= 100):
        return 0
    key = board._transposition_key()
    hit = TT.get(key)
    tt_move = None
    if hit is not None:
        d, s, f, mv = hit
        tt_move = mv
        if d >= depth and ply > 0:
            if f == 0:
                return s
            if f == 1 and s >= beta:
                return s
            if f == 2 and s <= alpha:
                return s
    if board.is_check():
        depth += 1
    if depth <= 0:
        return qsearch(board, alpha, beta, ply)

    moves = list(board.legal_moves)
    if not moves:
        return -MATE + ply if board.is_check() else 0

    # null move
    if (depth >= 3 and not board.is_check() and ply > 0
            and any(board.pieces(pt, board.turn)
                    for pt in (chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN))):
        board.push(chess.Move.null())
        v = -negamax(board, depth - 3, -beta, -beta + 1, ply + 1, killers)
        board.pop()
        if v >= beta:
            return v

    best, best_move, orig = -MATE, None, alpha
    for i, m in enumerate(order(board, moves, tt_move, killers, ply)):
        board.push(m)
        if i == 0:
            v = -negamax(board, depth - 1, -beta, -alpha, ply + 1, killers)
        else:
            r = 1 if (depth >= 3 and i >= 4 and not board.is_check()
                      and not board.is_capture(m)) else 0
            v = -negamax(board, depth - 1 - r, -alpha - 1, -alpha, ply + 1, killers)
            if alpha < v < beta:
                v = -negamax(board, depth - 1, -beta, -alpha, ply + 1, killers)
        board.pop()
        if v > best:
            best, best_move = v, m
            if v > alpha:
                alpha = v
                if v >= beta:
                    if not board.is_capture(m) and ply < len(killers):
                        killers[ply] = [m, killers[ply][0]]
                    break
    flag = 0 if orig < best < beta else (1 if best >= beta else 2)
    TT[key] = (depth, best, flag, best_move)
    return best


def get_move(fen, time_left_ms):
    board = chess.Board(fen)
    legal = list(board.legal_moves)
    if not legal:
        return "0000"
    if len(legal) == 1:
        return legal[0].uci()
    budget = max(time_left_ms - 60, 20) / 26.0 + 375.0
    _deadline[0] = time.time() + min(budget, (time_left_ms - 60) * 0.33) / 1000.0
    _nodes[0] = 0
    if len(TT) > 900000:
        TT.clear()
    killers = [[None, None] for _ in range(80)]
    best = legal[0]
    for depth in range(1, 40):
        try:
            negamax(board, depth, -MATE, MATE, 0, killers)
        except Timeout:
            break
        hit = TT.get(board._transposition_key())
        if hit and hit[3]:
            best = hit[3]
        if time.time() > _deadline[0] - 0.02:
            break
    return best.uci()
