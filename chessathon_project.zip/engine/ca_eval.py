"""Hand-crafted evaluation and static exchange evaluation.

Everything is tapered between a middlegame and an endgame score using a phase
count derived from the non-pawn material still on the board. Scores are in
centipawns from WHITE's point of view inside evaluate_white(); the search wraps
it to side-to-move.

Design note: with ~1.5M nodes/sec available, the eval budget per node is small.
Terms are ordered so the expensive ones (mobility, king safety) reuse attack
bitboards that were computed once.
"""
import numpy as np
from numba import njit

from ca_tables import (
    FILE_BB, ADJACENT_FILES, FRONT_SPAN, PASSED_MASK, KING_ZONE,
    SQ_DISTANCE, CENTER_MANHATTAN,
)
from ca_movegen import (
    popcount, lsb, bit, rook_attacks, bishop_attacks, queen_attacks,
    KNIGHT_ATTACKS, KING_ATTACKS, PAWN_ATTACKS, U0, U1,
    WP, WN, WB, WR, WQ, WK, BP, BN, BB_, BR, BQ, BK, EMPTY, WHITE, BLACK,
)

NOT_FILE_A = np.uint64(0xFEFEFEFEFEFEFEFE)
NOT_FILE_H = np.uint64(0x7F7F7F7F7F7F7F7F)
S7 = np.uint64(7)
S9 = np.uint64(9)


def _flip(table):
    """Tables below are written rank 8 first (as a board is drawn); the engine
    indexes a1 = 0, so reverse the rank order."""
    out = []
    for r in range(7, -1, -1):
        out.extend(table[r * 8:r * 8 + 8])
    return out


# --- material ---------------------------------------------------------------
MG_VALUE = np.array([85, 330, 350, 480, 1000, 0], dtype=np.int64)
EG_VALUE = np.array([100, 290, 310, 520, 950, 0], dtype=np.int64)
PHASE_WEIGHT = np.array([0, 1, 1, 2, 4, 0], dtype=np.int64)
TOTAL_PHASE = 24

# --- piece-square tables ----------------------------------------------------
_PAWN_MG = [
      0,   0,   0,   0,   0,   0,   0,   0,
     60,  70,  60,  60,  60,  60,  70,  60,
     15,  20,  30,  40,  40,  30,  20,  15,
      5,   8,  15,  28,  28,  12,   8,   5,
      0,   2,   8,  22,  22,   5,   2,   0,
      2,  -2,   2,   8,  10,   0,  -4,   2,
      2,   5,   5, -12, -12,   8,   8,   2,
      0,   0,   0,   0,   0,   0,   0,   0,
]
_PAWN_EG = [
      0,   0,   0,   0,   0,   0,   0,   0,
     95,  95,  90,  85,  85,  90,  95,  95,
     55,  55,  50,  45,  45,  50,  55,  55,
     30,  28,  24,  20,  20,  24,  28,  30,
     14,  13,  10,   8,   8,  10,  13,  14,
      6,   6,   4,   2,   2,   4,   6,   6,
      2,   2,   2,  -2,  -2,   2,   2,   2,
      0,   0,   0,   0,   0,   0,   0,   0,
]
_KNIGHT_MG = [
    -55, -40, -25, -20, -20, -25, -40, -55,
    -35, -15,   5,   8,   8,   5, -15, -35,
    -20,   8,  22,  28,  28,  22,   8, -20,
    -15,  10,  26,  32,  32,  26,  10, -15,
    -18,   6,  24,  30,  30,  24,   6, -18,
    -22,   4,  18,  22,  22,  18,   4, -22,
    -35, -18,   2,   8,   8,   2, -18, -35,
    -58, -32, -22, -16, -16, -22, -32, -58,
]
_KNIGHT_EG = [
    -45, -32, -18, -12, -12, -18, -32, -45,
    -30, -12,   0,   6,   6,   0, -12, -30,
    -16,   2,  14,  18,  18,  14,   2, -16,
    -12,   6,  18,  22,  22,  18,   6, -12,
    -12,   6,  18,  22,  22,  18,   6, -12,
    -16,   2,  12,  18,  18,  12,   2, -16,
    -30, -14,  -2,   4,   4,  -2, -14, -30,
    -48, -32, -20, -14, -14, -20, -32, -48,
]
_BISHOP_MG = [
    -18, -10, -12,  -8,  -8, -12, -10, -18,
    -10,   4,   0,   2,   2,   0,   4, -10,
     -6,   8,  12,  10,  10,  12,   8,  -6,
     -4,   6,  14,  18,  18,  14,   6,  -4,
     -4,   8,  14,  18,  18,  14,   8,  -4,
     -2,  14,  14,  12,  12,  14,  14,  -2,
     -6,  16,   6,   6,   6,   6,  16,  -6,
    -16,  -6,  -8, -12, -12,  -8,  -6, -16,
]
_BISHOP_EG = [
    -18, -10,  -8,  -4,  -4,  -8, -10, -18,
     -8,  -2,   2,   4,   4,   2,  -2,  -8,
     -4,   4,   8,  10,  10,   8,   4,  -4,
     -2,   6,  10,  14,  14,  10,   6,  -2,
     -2,   6,  10,  14,  14,  10,   6,  -2,
     -4,   4,   8,  10,  10,   8,   4,  -4,
     -8,  -2,   2,   4,   4,   2,  -2,  -8,
    -16,  -8,  -6,  -4,  -4,  -6,  -8, -16,
]
_ROOK_MG = [
      4,   4,   6,   8,   8,   6,   4,   4,
     14,  18,  20,  22,  22,  20,  18,  14,
     -2,   2,   6,   8,   8,   6,   2,  -2,
     -6,  -2,   2,   4,   4,   2,  -2,  -6,
     -8,  -4,   0,   2,   2,   0,  -4,  -8,
    -10,  -4,   0,   2,   2,   0,  -4, -10,
    -12,  -4,   0,   4,   4,   0,  -4, -12,
     -6,  -4,   4,  10,  10,   4,  -4,  -6,
]
_ROOK_EG = [
     10,   8,   8,   8,   8,   8,   8,  10,
     12,  12,  12,  10,  10,  12,  12,  12,
      8,   8,   8,   6,   6,   8,   8,   8,
      4,   4,   4,   4,   4,   4,   4,   4,
      0,   0,   2,   2,   2,   2,   0,   0,
     -4,  -2,   0,   0,   0,   0,  -2,  -4,
     -6,  -4,  -2,  -2,  -2,  -2,  -4,  -6,
     -8,  -4,  -2,  -2,  -2,  -2,  -4,  -8,
]
_QUEEN_MG = [
    -14,  -8,  -6,  -2,  -2,  -6,  -8, -14,
     -8,   0,   4,   4,   4,   4,   0,  -8,
     -6,   4,   6,   8,   8,   6,   4,  -6,
     -2,   4,   8,  10,  10,   8,   4,  -2,
      0,   6,   8,  10,  10,   8,   6,   0,
     -6,   6,   6,   8,   8,   6,   6,  -6,
     -8,   0,   6,   4,   4,   6,   0,  -8,
    -14,  -8,  -6,   0,   0,  -6,  -8, -14,
]
_QUEEN_EG = [
    -34, -20, -14,  -8,  -8, -14, -20, -34,
    -20,  -8,   0,   4,   4,   0,  -8, -20,
    -14,   0,   8,  14,  14,   8,   0, -14,
     -8,   4,  14,  20,  20,  14,   4,  -8,
     -8,   4,  14,  20,  20,  14,   4,  -8,
    -14,   0,   8,  14,  14,   8,   0, -14,
    -20,  -8,   0,   4,   4,   0,  -8, -20,
    -36, -22, -16, -10, -10, -16, -22, -36,
]
_KING_MG = [
    -60, -70, -70, -80, -80, -70, -70, -60,
    -55, -62, -66, -74, -74, -66, -62, -55,
    -45, -55, -60, -68, -68, -60, -55, -45,
    -38, -48, -54, -62, -62, -54, -48, -38,
    -28, -36, -44, -52, -52, -44, -36, -28,
    -14, -24, -30, -34, -34, -30, -24, -14,
     16,  16,  -6, -14, -14,  -6,  16,  16,
     22,  32,   8, -14,   0, -16,  30,  20,
]
_KING_EG = [
    -72, -40, -22, -12, -12, -22, -40, -72,
    -30,  -8,  10,  18,  18,  10,  -8, -30,
    -14,  14,  30,  36,  36,  30,  14, -14,
    -12,  18,  36,  44,  44,  36,  18, -12,
    -14,  16,  34,  42,  42,  34,  16, -14,
    -18,  10,  24,  30,  30,  24,  10, -18,
    -30,  -4,   8,  12,  12,   8,  -4, -30,
    -58, -34, -20, -14, -14, -20, -34, -58,
]

PST_MG = np.array([_flip(t) for t in
                   (_PAWN_MG, _KNIGHT_MG, _BISHOP_MG, _ROOK_MG, _QUEEN_MG, _KING_MG)],
                  dtype=np.int64)
PST_EG = np.array([_flip(t) for t in
                   (_PAWN_EG, _KNIGHT_EG, _BISHOP_EG, _ROOK_EG, _QUEEN_EG, _KING_EG)],
                  dtype=np.int64)

# --- other term weights -----------------------------------------------------
PASSED_MG = np.array([0, 4, 6, 12, 26, 50, 90, 0], dtype=np.int64)
PASSED_EG = np.array([0, 10, 18, 32, 58, 100, 160, 0], dtype=np.int64)

MOB_MG = np.array([0, 4, 4, 3, 2, 0], dtype=np.int64)
MOB_EG = np.array([0, 4, 5, 6, 5, 0], dtype=np.int64)
MOB_BASE = np.array([0, 4, 6, 7, 14, 0], dtype=np.int64)

KING_ATT_WEIGHT = np.array([0, 2, 2, 3, 5, 0], dtype=np.int64)

BISHOP_PAIR_MG = 30
BISHOP_PAIR_EG = 48
DOUBLED_MG, DOUBLED_EG = -8, -20
ISOLATED_MG, ISOLATED_EG = -13, -15
ROOK_OPEN_MG, ROOK_OPEN_EG = 20, 10
ROOK_SEMI_MG, ROOK_SEMI_EG = 9, 6
SHIELD_MISSING_MG = -14
TEMPO = 12

SEE_VALUE = np.array([100, 320, 330, 500, 900, 10000], dtype=np.int64)


@njit(cache=False, inline='always')
def pawn_attacks_bb(pawns, is_white):
    if is_white:
        return ((pawns & NOT_FILE_A) << S7) | ((pawns & NOT_FILE_H) << S9)
    return ((pawns & NOT_FILE_A) >> S9) | ((pawns & NOT_FILE_H) >> S7)


@njit(cache=False)
def evaluate(bb, occ, mail, st):
    """Static evaluation in centipawns, from the side to move's point of view."""
    mg = np.int64(0)
    eg = np.int64(0)
    phase = np.int64(0)

    wp = bb[WP]
    bp = bb[BP]
    all_occ = occ[2]
    w_pawn_att = pawn_attacks_bb(wp, True)
    b_pawn_att = pawn_attacks_bb(bp, False)
    wksq = lsb(bb[WK])
    bksq = lsb(bb[BK])
    w_zone = KING_ZONE[WHITE][wksq]
    b_zone = KING_ZONE[BLACK][bksq]
    w_danger = np.int64(0)
    b_danger = np.int64(0)

    for colour in range(2):
        base = np.int64(0) if colour == WHITE else np.int64(6)
        sign = np.int64(1) if colour == WHITE else np.int64(-1)
        own_occ = occ[colour]
        own_pawns = wp if colour == WHITE else bp
        enemy_pawn_att = b_pawn_att if colour == WHITE else w_pawn_att
        enemy_zone = b_zone if colour == WHITE else w_zone
        # squares that are not our own pieces and not attacked by enemy pawns
        mob_area = ~(own_occ | enemy_pawn_att)

        for pt in range(6):
            pieces = bb[base + pt]
            while pieces:
                sq = lsb(pieces)
                pieces &= pieces - U1
                rel = sq if colour == WHITE else sq ^ 56   # mirror for black
                mg += sign * (MG_VALUE[pt] + PST_MG[pt][rel])
                eg += sign * (EG_VALUE[pt] + PST_EG[pt][rel])
                phase += PHASE_WEIGHT[pt]

                if pt == 1:
                    att = KNIGHT_ATTACKS[sq]
                elif pt == 2:
                    att = bishop_attacks(sq, all_occ)
                elif pt == 3:
                    att = rook_attacks(sq, all_occ)
                elif pt == 4:
                    att = queen_attacks(sq, all_occ)
                else:
                    att = U0

                if pt >= 1 and pt <= 4:
                    m = popcount(att & mob_area) - MOB_BASE[pt]
                    mg += sign * m * MOB_MG[pt]
                    eg += sign * m * MOB_EG[pt]
                    zone_hits = popcount(att & enemy_zone)
                    if zone_hits > 0:
                        d = KING_ATT_WEIGHT[pt] * zone_hits
                        if colour == WHITE:
                            b_danger += d
                        else:
                            w_danger += d

                if pt == 3:                       # rook file quality
                    f = sq & 7
                    if (FILE_BB[f] & own_pawns) == 0:
                        enemy_pawns = bp if colour == WHITE else wp
                        if (FILE_BB[f] & enemy_pawns) == 0:
                            mg += sign * ROOK_OPEN_MG
                            eg += sign * ROOK_OPEN_EG
                        else:
                            mg += sign * ROOK_SEMI_MG
                            eg += sign * ROOK_SEMI_EG

                if pt == 0:                       # pawn structure
                    f = sq & 7
                    enemy_pawns = bp if colour == WHITE else wp
                    if (PASSED_MASK[colour][sq] & enemy_pawns) == 0:
                        r = (sq >> 3) if colour == WHITE else 7 - (sq >> 3)
                        mg += sign * PASSED_MG[r]
                        eg += sign * PASSED_EG[r]
                        # a passer defended by another pawn is worth more
                        if (bit(sq) & (w_pawn_att if colour == WHITE else b_pawn_att)) != 0:
                            eg += sign * (PASSED_EG[r] >> 2)
                    if (ADJACENT_FILES[f] & own_pawns) == 0:
                        mg += sign * ISOLATED_MG
                        eg += sign * ISOLATED_EG
                    if (FRONT_SPAN[colour][sq] & own_pawns) != 0:
                        mg += sign * DOUBLED_MG
                        eg += sign * DOUBLED_EG

        # bishop pair
        if popcount(bb[base + 2]) >= 2:
            mg += sign * BISHOP_PAIR_MG
            eg += sign * BISHOP_PAIR_EG

    # --- pawn shield in front of each king -----------------------------------
    for colour in range(2):
        ksq = wksq if colour == WHITE else bksq
        own_pawns = wp if colour == WHITE else bp
        sign = np.int64(1) if colour == WHITE else np.int64(-1)
        kf = ksq & 7
        lo = kf - 1 if kf > 0 else 0
        hi = kf + 1 if kf < 7 else 7
        for f in range(lo, hi + 1):
            if (FILE_BB[f] & own_pawns & FRONT_SPAN[colour][ksq - (ksq & 7) + f]) == 0:
                mg += sign * SHIELD_MISSING_MG

    # --- king danger (quadratic in accumulated attack units) -----------------
    if w_danger > 0:
        d = w_danger if w_danger < 40 else np.int64(40)
        mg -= (d * d) >> 2
    if b_danger > 0:
        d = b_danger if b_danger < 40 else np.int64(40)
        mg += (d * d) >> 2

    if phase > TOTAL_PHASE:
        phase = np.int64(TOTAL_PHASE)
    num = mg * phase + eg * (TOTAL_PHASE - phase)
    # truncate toward zero so that evaluation is exactly colour-symmetric;
    # floor division would round negative scores the other way and break it
    if num >= 0:
        score = num // TOTAL_PHASE
    else:
        score = -((-num) // TOTAL_PHASE)

    if st[0] == BLACK:
        score = -score
    return score + TEMPO


# =============================================================================
# Static exchange evaluation
#
# Plays out the capture sequence on `to` with the least valuable attacker each
# time, updating x-ray attackers as pieces are removed, and returns the
# material swing in centipawns. Used to skip losing captures in quiescence and
# to order captures in the main search.
# =============================================================================
@njit(cache=False)
def _all_attackers(bb, occ_now, sq):
    res = PAWN_ATTACKS[BLACK][sq] & bb[WP]
    res |= PAWN_ATTACKS[WHITE][sq] & bb[BP]
    res |= KNIGHT_ATTACKS[sq] & (bb[WN] | bb[BN])
    res |= KING_ATTACKS[sq] & (bb[WK] | bb[BK])
    ba = bishop_attacks(sq, occ_now)
    res |= ba & (bb[WB] | bb[BB_] | bb[WQ] | bb[BQ])
    ra = rook_attacks(sq, occ_now)
    res |= ra & (bb[WR] | bb[BR] | bb[WQ] | bb[BQ])
    return res & occ_now


@njit(cache=False)
def see(bb, occ, mail, frm, to, side):
    """Material the side to move wins by initiating a capture on `to`."""
    gain = np.zeros(34, dtype=np.int64)
    occ_now = occ[2]
    victim = mail[to]
    d = 0
    gain[0] = SEE_VALUE[np.int64(victim) % 6] if victim != EMPTY else np.int64(0)
    attacker_sq = frm
    stm = side

    attackers = _all_attackers(bb, occ_now, to)
    moving = mail[frm]

    while True:
        d += 1
        if d >= 32:
            break
        gain[d] = SEE_VALUE[np.int64(moving) % 6] - gain[d - 1]
        # remove the attacker we just used and re-expose x-rays behind it
        occ_now ^= bit(attacker_sq)
        attackers &= ~bit(attacker_sq)
        attackers |= (bishop_attacks(to, occ_now) &
                      (bb[WB] | bb[BB_] | bb[WQ] | bb[BQ]))
        attackers |= (rook_attacks(to, occ_now) &
                      (bb[WR] | bb[BR] | bb[WQ] | bb[BQ]))
        attackers &= occ_now

        stm = 1 - stm
        side_att = attackers & occ[stm] & occ_now
        if side_att == 0:
            break
        # least valuable attacker for `stm`
        base = np.int64(0) if stm == WHITE else np.int64(6)
        found = -1
        for pt in range(6):
            cand = side_att & bb[base + pt]
            if cand != 0:
                attacker_sq = lsb(cand)
                found = pt
                break
        if found < 0:
            break
        moving = base + found

    while d > 1:
        d -= 1
        if -gain[d] < gain[d - 1]:
            gain[d - 1] = -gain[d]
    return gain[0]
