"""Bitboard position representation, legal move generation, make/unmake.

The position is four numpy arrays, passed explicitly to every function so that
numba can compile against concrete types:

    bb   uint64[12]  piece bitboards, indexed WP..BK
    occ  uint64[3]   [white, black, both]
    mail int8[64]    piece index per square, 12 == empty
    st   int64[5]    [side, castling, ep_square, halfmove, fullmove]
    hsh  uint64[1]   zobrist key (separate array: it must stay unsigned)

Bitboards are uint64 and indices are int64, and the two are never mixed inside
one arithmetic expression -- numba promotes uint64 + int64 to float64.

Moves are packed into one int32:

    bits  0-5   from square
    bits  6-11  to square
    bits 12-14  promotion piece type (0 none, 1 N, 2 B, 3 R, 4 Q)
    bit  15     en passant capture
    bit  16     castling
    bits 17-20  moving piece (0..11)
    bits 21-24  captured piece (0..11, 12 = none)
    bit  25     double pawn push
"""
import numpy as np
from numba import njit

from ca_tables import (
    KNIGHT_ATTACKS, KING_ATTACKS, PAWN_ATTACKS,
    ROOK_TABLE, ROOK_MASKS, ROOK_MAGIC, ROOK_SHIFT, ROOK_OFFSET,
    BISHOP_TABLE, BISHOP_MASKS, BISHOP_MAGIC, BISHOP_SHIFT, BISHOP_OFFSET,
    BETWEEN, LINE, DEBRUIJN, DEBRUIJN_INDEX,
    ZOBRIST_PIECE, ZOBRIST_CASTLE, ZOBRIST_EP, ZOBRIST_SIDE, CASTLE_MASK,
)

WP, WN, WB, WR, WQ, WK, BP, BN, BB_, BR, BQ, BK = range(12)
EMPTY = 12
WHITE, BLACK = 0, 1
MAX_MOVES = 256

RANK_1_BB = np.uint64(0x00000000000000FF)
RANK_8_BB = np.uint64(0xFF00000000000000)
U0 = np.uint64(0)
U1 = np.uint64(1)
UALL = np.uint64(0xFFFFFFFFFFFFFFFF)


# =============================================================================
# Bit primitives
# =============================================================================
M55 = np.uint64(0x5555555555555555)
M33 = np.uint64(0x3333333333333333)
M0F = np.uint64(0x0F0F0F0F0F0F0F0F)
M01 = np.uint64(0x0101010101010101)
S1 = np.uint64(1)
S2 = np.uint64(2)
S4 = np.uint64(4)
S56 = np.uint64(56)
S58 = np.uint64(58)


@njit(cache=False, inline='always')
def popcount(b):
    """SWAR population count. Returns int64 so it can be compared and counted
    against ordinary integers without dragging uint64 into the expression."""
    x = b - ((b >> S1) & M55)
    x = (x & M33) + ((x >> S2) & M33)
    x = (x + (x >> S4)) & M0F
    return np.int64((x * M01) >> S56)


@njit(cache=False, inline='always')
def lsb(b):
    """Index of the least significant set bit (b must be non-zero)."""
    low = b & (U0 - b)
    return DEBRUIJN_INDEX[np.int64((low * DEBRUIJN) >> S58)]


@njit(cache=False, inline='always')
def bit(sq):
    return U1 << np.uint64(sq)


# =============================================================================
# Attack lookups
# =============================================================================
@njit(cache=False, inline='always')
def rook_attacks(sq, occ):
    o = occ & ROOK_MASKS[sq]
    idx = np.int64((o * ROOK_MAGIC[sq]) >> ROOK_SHIFT[sq])
    return ROOK_TABLE[ROOK_OFFSET[sq] + idx]


@njit(cache=False, inline='always')
def bishop_attacks(sq, occ):
    o = occ & BISHOP_MASKS[sq]
    idx = np.int64((o * BISHOP_MAGIC[sq]) >> BISHOP_SHIFT[sq])
    return BISHOP_TABLE[BISHOP_OFFSET[sq] + idx]


@njit(cache=False, inline='always')
def queen_attacks(sq, occ):
    return rook_attacks(sq, occ) | bishop_attacks(sq, occ)


@njit(cache=False)
def attackers_to(bb, occ_all, sq, by_black):
    """Bitboard of `by_black` side's pieces attacking `sq` over `occ_all`."""
    if by_black:
        p, n, b, r, q, k = BP, BN, BB_, BR, BQ, BK
        pawn_att = PAWN_ATTACKS[WHITE][sq]   # squares a black pawn attacks sq from
    else:
        p, n, b, r, q, k = WP, WN, WB, WR, WQ, WK
        pawn_att = PAWN_ATTACKS[BLACK][sq]
    res = pawn_att & bb[p]
    res |= KNIGHT_ATTACKS[sq] & bb[n]
    res |= KING_ATTACKS[sq] & bb[k]
    ba = bishop_attacks(sq, occ_all)
    res |= ba & (bb[b] | bb[q])
    ra = rook_attacks(sq, occ_all)
    res |= ra & (bb[r] | bb[q])
    return res


@njit(cache=False)
def is_attacked(bb, occ_all, sq, by_black):
    return attackers_to(bb, occ_all, sq, by_black) != 0


# =============================================================================
# Move packing
# =============================================================================
@njit(cache=False, inline='always')
def mk_move(frm, to, promo, ep, castle, piece, captured, dbl):
    f = np.int64(frm)
    t = np.int64(to)
    pr = np.int64(promo)
    e = np.int64(ep)
    c = np.int64(castle)
    p = np.int64(piece)
    v = np.int64(captured)
    d = np.int64(dbl)
    return np.int32(f | (t << 6) | (pr << 12) | (e << 15) | (c << 16) |
                    (p << 17) | (v << 21) | (d << 25))


@njit(cache=False, inline='always')
def m_from(m):
    return m & 63


@njit(cache=False, inline='always')
def m_to(m):
    return (m >> 6) & 63


@njit(cache=False, inline='always')
def m_promo(m):
    return (m >> 12) & 7


@njit(cache=False, inline='always')
def m_is_ep(m):
    return (m >> 15) & 1


@njit(cache=False, inline='always')
def m_is_castle(m):
    return (m >> 16) & 1


@njit(cache=False, inline='always')
def m_piece(m):
    return (m >> 17) & 15


@njit(cache=False, inline='always')
def m_captured(m):
    return (m >> 21) & 15


@njit(cache=False, inline='always')
def m_is_dbl(m):
    return (m >> 25) & 1


# =============================================================================
# Legal move generation
#
# Fully legal, not pseudo-legal: we compute the check mask and the pin set up
# front, so no generated move ever has to be verified by making it. The only
# exceptions are king moves (tested against the enemy attack set with our own
# king removed from the occupancy, so sliders x-ray through it) and en passant,
# which gets an explicit check test because of the horizontal discovery.
# =============================================================================
@njit(cache=False)
def gen_moves(bb, occ, mail, st, out, captures_only):
    n = 0
    side = st[0]
    up = np.int64(0) if side == WHITE else np.int64(6)   # our piece base index
    tp = np.int64(6) - up                                # their piece base index
    them_black = np.int64(1) - side

    us_occ = occ[side]
    them_occ = occ[1 - side]
    all_occ = occ[2]
    ksq = lsb(bb[up + 5])

    checkers = attackers_to(bb, all_occ, ksq, them_black)
    n_check = popcount(checkers)

    if n_check >= 2:
        target = U0                   # double check: only the king may move
    elif n_check == 1:
        csq = lsb(checkers)
        target = BETWEEN[ksq][csq] | checkers
    else:
        target = ~us_occ
        if captures_only:
            target &= them_occ

    # --- pinned pieces -------------------------------------------------------
    pinned = U0
    snipers = (rook_attacks(ksq, U0) & (bb[tp + 3] | bb[tp + 4])) | \
              (bishop_attacks(ksq, U0) & (bb[tp + 2] | bb[tp + 4]))
    s = snipers
    while s:
        ssq = lsb(s)
        s &= s - U1
        blockers = BETWEEN[ksq][ssq] & all_occ
        if blockers != 0 and (blockers & (blockers - U1)) == 0 \
                and (blockers & us_occ) != 0:
            pinned |= blockers

    # --- pawns ---------------------------------------------------------------
    pawns = bb[up + 0]
    promo_rank = RANK_8_BB if side == WHITE else RANK_1_BB
    p = pawns
    while p:
        frm = lsb(p)
        p &= p - U1
        mask = target
        if (pinned & bit(frm)) != 0:
            mask &= LINE[ksq][frm]

        # captures
        caps = PAWN_ATTACKS[side][frm] & them_occ & mask
        while caps:
            to = lsb(caps)
            caps &= caps - U1
            victim = mail[to]
            if (bit(to) & promo_rank) != 0:
                for pr in range(4, 0, -1):
                    out[n] = mk_move(frm, to, pr, 0, 0, up + 0, victim, 0)
                    n += 1
            else:
                out[n] = mk_move(frm, to, 0, 0, 0, up + 0, victim, 0)
                n += 1

        # pushes
        if not captures_only or n_check > 0:
            one = frm + 8 if side == WHITE else frm - 8
            if (all_occ & bit(one)) == 0:
                if (bit(one) & mask) != 0:
                    if (bit(one) & promo_rank) != 0:
                        for pr in range(4, 0, -1):
                            out[n] = mk_move(frm, one, pr, 0, 0, up + 0, EMPTY, 0)
                            n += 1
                    else:
                        out[n] = mk_move(frm, one, 0, 0, 0, up + 0, EMPTY, 0)
                        n += 1
                start_rank = (frm >> 3) == 1 if side == WHITE else (frm >> 3) == 6
                if start_rank:
                    two = frm + 16 if side == WHITE else frm - 16
                    if (all_occ & bit(two)) == 0 and (bit(two) & mask) != 0:
                        out[n] = mk_move(frm, two, 0, 0, 0, up + 0, EMPTY, 1)
                        n += 1
        else:
            # in quiescence we still want queen promotions by pushing
            one = frm + 8 if side == WHITE else frm - 8
            pin_ok = (pinned & bit(frm)) == 0 or (LINE[ksq][frm] & bit(one)) != 0
            if (all_occ & bit(one)) == 0 and (bit(one) & promo_rank) != 0 \
                    and pin_ok:
                out[n] = mk_move(frm, one, 4, 0, 0, up + 0, EMPTY, 0)
                n += 1

    # --- en passant ----------------------------------------------------------
    ep = st[2]
    if ep >= 0:
        cands = PAWN_ATTACKS[1 - side][ep] & bb[up + 0]
        while cands:
            frm = lsb(cands)
            cands &= cands - U1
            capsq = ep - 8 if side == WHITE else ep + 8
            new_occ = (all_occ ^ bit(frm) ^ bit(capsq)) | bit(ep)
            # full check test: the captured pawn is gone from the board
            danger = PAWN_ATTACKS[side][ksq] & (bb[tp + 0] ^ bit(capsq))
            danger |= KNIGHT_ATTACKS[ksq] & bb[tp + 1]
            danger |= KING_ATTACKS[ksq] & bb[tp + 5]
            danger |= bishop_attacks(ksq, new_occ) & (bb[tp + 2] | bb[tp + 4])
            danger |= rook_attacks(ksq, new_occ) & (bb[tp + 3] | bb[tp + 4])
            if danger == 0:
                out[n] = mk_move(frm, ep, 0, 1, 0, up + 0, tp + 0, 0)
                n += 1

    # --- knights -------------------------------------------------------------
    b = bb[up + 1]
    while b:
        frm = lsb(b)
        b &= b - U1
        if (pinned & bit(frm)) != 0:
            continue                      # a pinned knight can never move
        att = KNIGHT_ATTACKS[frm] & target
        while att:
            to = lsb(att)
            att &= att - U1
            out[n] = mk_move(frm, to, 0, 0, 0, up + 1, mail[to], 0)
            n += 1

    # --- bishops, rooks, queens ---------------------------------------------
    for kind in range(3):
        b = bb[up + 2 + kind]
        while b:
            frm = lsb(b)
            b &= b - U1
            if kind == 0:
                att = bishop_attacks(frm, all_occ)
            elif kind == 1:
                att = rook_attacks(frm, all_occ)
            else:
                att = queen_attacks(frm, all_occ)
            att &= target
            if (pinned & bit(frm)) != 0:
                att &= LINE[ksq][frm]
            while att:
                to = lsb(att)
                att &= att - U1
                out[n] = mk_move(frm, to, 0, 0, 0, up + 2 + kind, mail[to], 0)
                n += 1

    # --- king ----------------------------------------------------------------
    occ_no_king = all_occ ^ bit(ksq)
    kmoves = KING_ATTACKS[ksq] & ~us_occ
    if captures_only and n_check == 0:
        kmoves &= them_occ
    while kmoves:
        to = lsb(kmoves)
        kmoves &= kmoves - U1
        if not is_attacked(bb, occ_no_king, to, them_black):
            out[n] = mk_move(ksq, to, 0, 0, 0, up + 5, mail[to], 0)
            n += 1

    # --- castling ------------------------------------------------------------
    if n_check == 0 and not captures_only:
        cr = st[1]
        if side == WHITE:
            if (cr & 1) != 0 and (all_occ & np.uint64(0x60)) == 0:
                if not is_attacked(bb, all_occ, np.int64(5), them_black) and \
                   not is_attacked(bb, all_occ, np.int64(6), them_black):
                    out[n] = mk_move(np.int64(4), np.int64(6), 0, 0, 1, WK, EMPTY, 0)
                    n += 1
            if (cr & 2) != 0 and (all_occ & np.uint64(0x0E)) == 0:
                if not is_attacked(bb, all_occ, np.int64(3), them_black) and \
                   not is_attacked(bb, all_occ, np.int64(2), them_black):
                    out[n] = mk_move(np.int64(4), np.int64(2), 0, 0, 1, WK, EMPTY, 0)
                    n += 1
        else:
            if (cr & 4) != 0 and (all_occ & np.uint64(0x6000000000000000)) == 0:
                if not is_attacked(bb, all_occ, np.int64(61), them_black) and \
                   not is_attacked(bb, all_occ, np.int64(62), them_black):
                    out[n] = mk_move(np.int64(60), np.int64(62), 0, 0, 1, BK, EMPTY, 0)
                    n += 1
            if (cr & 8) != 0 and (all_occ & np.uint64(0x0E00000000000000)) == 0:
                if not is_attacked(bb, all_occ, np.int64(59), them_black) and \
                   not is_attacked(bb, all_occ, np.int64(58), them_black):
                    out[n] = mk_move(np.int64(60), np.int64(58), 0, 0, 1, BK, EMPTY, 0)
                    n += 1

    return n


# =============================================================================
# make / unmake
#
# undo[ply] = [castling, ep, halfmove] and undo_h[ply] = zobrist key, which is
# everything unmake cannot reconstruct. The captured piece rides in the move.
# The hash lives in its own uint64 array because st is int64.
# =============================================================================
@njit(cache=False)
def make_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m):
    frm = np.int64(m_from(m))
    to = np.int64(m_to(m))
    pc = np.int64(m_piece(m))
    cap = np.int64(m_captured(m))
    promo = np.int64(m_promo(m))
    side = st[0]
    up = np.int64(0) if side == WHITE else np.int64(6)

    undo[ply, 0] = st[1]
    undo[ply, 1] = st[2]
    undo[ply, 2] = st[3]
    undo_h[ply] = hsh[0]

    h = hsh[0]
    if st[2] >= 0:
        h ^= ZOBRIST_EP[st[2] & 7]
    h ^= ZOBRIST_CASTLE[st[1]]

    # lift the moving piece
    bb[pc] ^= bit(frm)
    occ[side] ^= bit(frm)
    mail[frm] = np.int8(EMPTY)
    h ^= ZOBRIST_PIECE[pc][frm]

    # remove the captured piece
    if m_is_ep(m):
        capsq = to - 8 if side == WHITE else to + 8
        vict = np.int64(6) - up          # enemy pawn index
        bb[vict] ^= bit(capsq)
        occ[1 - side] ^= bit(capsq)
        mail[capsq] = np.int8(EMPTY)
        h ^= ZOBRIST_PIECE[vict][capsq]
    elif cap != EMPTY:
        bb[cap] ^= bit(to)
        occ[1 - side] ^= bit(to)
        h ^= ZOBRIST_PIECE[cap][to]

    # drop the piece, promoting if required
    newpc = up + promo if promo != 0 else pc
    bb[newpc] ^= bit(to)
    occ[side] ^= bit(to)
    mail[to] = np.int8(newpc)
    h ^= ZOBRIST_PIECE[newpc][to]

    # castling drags the rook along
    if m_is_castle(m):
        if to == 6:
            rf, rt, rp = np.int64(7), np.int64(5), np.int64(WR)
        elif to == 2:
            rf, rt, rp = np.int64(0), np.int64(3), np.int64(WR)
        elif to == 62:
            rf, rt, rp = np.int64(63), np.int64(61), np.int64(BR)
        else:
            rf, rt, rp = np.int64(56), np.int64(59), np.int64(BR)
        bb[rp] ^= bit(rf) | bit(rt)
        occ[side] ^= bit(rf) | bit(rt)
        mail[rf] = np.int8(EMPTY)
        mail[rt] = np.int8(rp)
        h ^= ZOBRIST_PIECE[rp][rf] ^ ZOBRIST_PIECE[rp][rt]

    st[1] = st[1] & CASTLE_MASK[frm] & CASTLE_MASK[to]
    h ^= ZOBRIST_CASTLE[st[1]]

    if m_is_dbl(m):
        st[2] = (frm + to) >> 1
        h ^= ZOBRIST_EP[st[2] & 7]
    else:
        st[2] = np.int64(-1)

    if pc == WP or pc == BP or cap != EMPTY or m_is_ep(m):
        st[3] = np.int64(0)
    else:
        st[3] += 1

    if side == BLACK:
        st[4] += 1
    st[0] = np.int64(1) - side
    h ^= ZOBRIST_SIDE
    hsh[0] = h
    occ[2] = occ[0] | occ[1]


@njit(cache=False)
def unmake_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m):
    frm = np.int64(m_from(m))
    to = np.int64(m_to(m))
    pc = np.int64(m_piece(m))
    cap = np.int64(m_captured(m))
    promo = np.int64(m_promo(m))

    side = np.int64(1) - st[0]           # the side that made the move
    up = np.int64(0) if side == WHITE else np.int64(6)

    if st[0] == WHITE:
        st[4] -= 1
    st[0] = side
    st[1] = undo[ply, 0]
    st[2] = undo[ply, 1]
    st[3] = undo[ply, 2]
    hsh[0] = undo_h[ply]

    if m_is_castle(m):
        if to == 6:
            rf, rt, rp = np.int64(7), np.int64(5), np.int64(WR)
        elif to == 2:
            rf, rt, rp = np.int64(0), np.int64(3), np.int64(WR)
        elif to == 62:
            rf, rt, rp = np.int64(63), np.int64(61), np.int64(BR)
        else:
            rf, rt, rp = np.int64(56), np.int64(59), np.int64(BR)
        bb[rp] ^= bit(rf) | bit(rt)
        occ[side] ^= bit(rf) | bit(rt)
        mail[rt] = np.int8(EMPTY)
        mail[rf] = np.int8(rp)

    newpc = up + promo if promo != 0 else pc
    bb[newpc] ^= bit(to)
    occ[side] ^= bit(to)
    mail[to] = np.int8(EMPTY)

    bb[pc] ^= bit(frm)
    occ[side] ^= bit(frm)
    mail[frm] = np.int8(pc)

    if m_is_ep(m):
        capsq = to - 8 if side == WHITE else to + 8
        vict = np.int64(6) - up
        bb[vict] ^= bit(capsq)
        occ[1 - side] ^= bit(capsq)
        mail[capsq] = np.int8(vict)
    elif cap != EMPTY:
        bb[cap] ^= bit(to)
        occ[1 - side] ^= bit(to)
        mail[to] = np.int8(cap)

    occ[2] = occ[0] | occ[1]


@njit(cache=False)
def make_null(st, hsh, undo, undo_h, ply):
    """Hand the move to the opponent, for null-move pruning."""
    undo[ply, 0] = st[1]
    undo[ply, 1] = st[2]
    undo[ply, 2] = st[3]
    undo_h[ply] = hsh[0]
    h = hsh[0]
    if st[2] >= 0:
        h ^= ZOBRIST_EP[st[2] & 7]
    st[2] = np.int64(-1)
    st[0] = np.int64(1) - st[0]
    h ^= ZOBRIST_SIDE
    hsh[0] = h
    st[3] += 1


@njit(cache=False)
def unmake_null(st, hsh, undo, undo_h, ply):
    st[0] = np.int64(1) - st[0]
    st[1] = undo[ply, 0]
    st[2] = undo[ply, 1]
    st[3] = undo[ply, 2]
    hsh[0] = undo_h[ply]


@njit(cache=False)
def in_check(bb, occ, st):
    side = st[0]
    up = np.int64(0) if side == WHITE else np.int64(6)
    return is_attacked(bb, occ[2], lsb(bb[up + 5]), np.int64(1) - side)


@njit(cache=False)
def compute_hash(bb, st):
    h = U0
    for pc in range(12):
        b = bb[pc]
        while b:
            sq = lsb(b)
            b &= b - U1
            h ^= ZOBRIST_PIECE[pc][sq]
    h ^= ZOBRIST_CASTLE[st[1]]
    if st[2] >= 0:
        h ^= ZOBRIST_EP[st[2] & 7]
    if st[0] == BLACK:
        h ^= ZOBRIST_SIDE
    return h
