"""One agent, one process. Reads {"fen","ms"} lines, writes {"move"} lines."""
import sys, json, traceback
sys.path.insert(0, sys.argv[1])
mod = __import__(sys.argv[2])
print("ready", flush=True)
for line in sys.stdin:
    line = line.strip()
    if not line or line == "quit":
        break
    try:
        req = json.loads(line)
        mv = mod.get_move(req["fen"], req["ms"])
        print(json.dumps({"move": mv}), flush=True)
    except Exception:
        print(json.dumps({"error": traceback.format_exc()[-400:]}), flush=True)
