import sys; sys.path.insert(0,'engine')
import numpy as np, chess
from ca_eval import evaluate, see
from ca_position import new_position, from_fen
from ca_movegen import gen_moves
from ca_position import new_stacks, move_to_uci

bb, occ, mail, st, hsh = new_position()
undo, undo_h, moves = new_stacks()

print("--- symmetry: eval(pos) must equal eval(mirrored pos) ---")
def mirror_fen(fen):
    b = chess.Board(fen)
    return b.mirror().fen()
bad = 0
tests = [
    chess.STARTING_FEN,
    "r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4",
    "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
    "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
    "8/5k2/8/8/8/8/3K1P2/8 w - - 0 1",
    "4k3/8/8/8/8/8/4P3/4K3 w - - 0 1",
]
for fen in tests:
    from_fen(fen, bb, occ, mail, st, hsh); a = int(evaluate(bb, occ, mail, st))
    from_fen(mirror_fen(fen), bb, occ, mail, st, hsh); b = int(evaluate(bb, occ, mail, st))
    ok = (a == b)
    bad += not ok
    print("  %6d vs %6d  %s  %s" % (a, b, "OK" if ok else "*** ASYMMETRIC ***", fen[:44]))
print("asymmetries:", bad)

print("\n--- SEE sanity ---")
cases = [
    ("1k1r4/1pp4p/p7/4p3/8/P5P1/1PP4P/2K1R3 w - - 0 1", "e1e5", 100),   # RxP, pawn defended by nothing -> +100
    ("1k1r3q/1ppn3p/p4b2/4p3/8/P2N2P1/1PP1R1BP/2K1Q3 w - - 0 1", "d3e5", -220), # NxP loses
    ("2r5/8/8/8/8/8/8/2R1K3 w - - 0 1", "c1c8", 500),
]
for fen, uci, expect in cases:
    from_fen(fen, bb, occ, mail, st, hsh)
    n = gen_moves(bb, occ, mail, st, moves[0], False)
    got = None
    for i in range(n):
        if move_to_uci(moves[0][i]) == uci:
            m = int(moves[0][i])
            got = int(see(bb, occ, mail, m & 63, (m >> 6) & 63, st[0]))
    print("  %-6s see=%-6s expect~%-6d %s" % (uci, got, expect, fen[:40]))
