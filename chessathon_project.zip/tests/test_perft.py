"""Perft: the only acceptable proof that move generation is correct.

Node counts are the published reference values for these positions; we also
cross-check every one against python-chess's own generator at low depth.
"""
import sys, time
sys.path.insert(0, '../engine'); sys.path.insert(0, 'engine')
import numpy as np
from numba import njit
import chess

from ca_movegen import gen_moves, make_move, unmake_move
from ca_position import new_position, new_stacks, from_fen


@njit(cache=False)
def perft(bb, occ, mail, st, hsh, undo, undo_h, moves, depth, ply):
    n = gen_moves(bb, occ, mail, st, moves[ply], False)
    if depth <= 1:
        return n
    total = 0
    for i in range(n):
        m = moves[ply][i]
        make_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m)
        total += perft(bb, occ, mail, st, hsh, undo, undo_h, moves,
                       depth - 1, ply + 1)
        unmake_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m)
    return total


SUITE = [
    # (name, fen, [perft(1), perft(2), ...])
    ("startpos", chess.STARTING_FEN,
     [20, 400, 8902, 197281, 4865609]),
    ("kiwipete", "r3k2r/p1ppqpb1/bn2pnp1/3PN3/1p2P3/2N2Q1p/PPPBBPPP/R3K2R w KQkq - 0 1",
     [48, 2039, 97862, 4085603]),
    ("position3", "8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1",
     [14, 191, 2812, 43238, 674624]),
    ("position4", "r3k2r/Pppp1ppp/1b3nbN/nP6/BBP1P3/q4N2/Pp1P2PP/R2Q1RK1 w kq - 0 1",
     [6, 264, 9467, 422333]),
    ("position4b", "r2q1rk1/pP1p2pp/Q4n2/bbp1p3/Np6/1B3NBn/pPPP1PPP/R3K2R b KQ - 0 1",
     [6, 264, 9467, 422333]),
    ("position5", "rnbq1k1r/pp1Pbppp/2p5/8/2B5/8/PPP1NnPP/RNBQK2R w KQ - 1 8",
     [44, 1486, 62379, 2103487]),
    ("position6", "r4rk1/1pp1qppp/p1np1n2/2b1p1B1/2B1P1b1/P1NP1N2/1PP1QPPP/R4RK1 w - - 0 10",
     [46, 2079, 89890, 3894594]),
    ("ep-tricky", "8/8/8/8/k1p4R/8/3P4/4K3 w - - 0 1", [18, 93, 1715, 10780]),
    ("promo-heavy", "n1n5/PPPk4/8/8/8/8/4Kppp/5N1N b - - 0 1", [24, 496, 9483, 182838]),
]


def main():
    bb, occ, mail, st, hsh = new_position()
    undo, undo_h, moves = new_stacks()

    t0 = time.time()
    from_fen(chess.STARTING_FEN, bb, occ, mail, st, hsh)
    perft(bb, occ, mail, st, hsh, undo, undo_h, moves, 1, 0)
    print("jit compile: %.1fs" % (time.time() - t0))

    failures = 0
    total_nodes = 0
    t0 = time.time()
    for name, fen, counts in SUITE:
        for d, expect in enumerate(counts, start=1):
            if expect == 0:
                continue
            from_fen(fen, bb, occ, mail, st, hsh)
            got = perft(bb, occ, mail, st, hsh, undo, undo_h, moves, d, 0)
            total_nodes += got
            ok = (got == expect)
            if not ok:
                failures += 1
            print("  %-11s depth %d  expect %10d  got %10d  %s"
                  % (name, d, expect, got, "OK" if ok else "*** FAIL ***"))
    dt = time.time() - t0
    print("\n%d nodes in %.2fs = %.2f Mnps (perft, no eval)"
          % (total_nodes, dt, total_nodes / dt / 1e6))
    print("failures:", failures)
    return failures


if __name__ == "__main__":
    sys.exit(1 if main() else 0)
