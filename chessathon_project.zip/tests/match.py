"""Head-to-head match between two agents, colours alternated per opening."""
import sys, os, math, time
sys.path.insert(0, os.path.dirname(__file__))
import arena
from openings import BALANCED


def elo(score, n):
    if n == 0:
        return 0.0, 0.0
    p = score / n
    if p <= 0.0:
        return -800.0, 0.0
    if p >= 1.0:
        return 800.0, 0.0
    e = -400.0 * math.log10(1.0 / p - 1.0)
    # standard error of the score rate -> Elo margin
    se = math.sqrt(max(p * (1 - p) / n, 1e-12))
    lo = max(min(p - 1.96 * se, 0.999), 0.001)
    hi = max(min(p + 1.96 * se, 0.999), 0.001)
    elo_lo = -400.0 * math.log10(1.0 / lo - 1.0)
    elo_hi = -400.0 * math.log10(1.0 / hi - 1.0)
    return e, (elo_hi - elo_lo) / 2.0


def run(dir_a, mod_a, dir_b, mod_b, n_pairs, base_ms, inc_ms, label=""):
    A = arena.Engine(dir_a, mod_a)
    B = arena.Engine(dir_b, mod_b)
    w = d = l = 0
    losses = []
    t0 = time.time()
    try:
        for i in range(n_pairs):
            fen = BALANCED[i % len(BALANCED)]
            for a_is_white in (True, False):
                white, black = (A, B) if a_is_white else (B, A)
                res, why, board = arena.play(white, black, fen,
                                             base_ms=base_ms, inc_ms=inc_ms)
                if res == "1/2-1/2":
                    d += 1
                elif (res == "1-0") == a_is_white:
                    w += 1
                else:
                    l += 1
                    losses.append(why)
                if why.startswith(("crash", "illegal", "flag", "malformed")):
                    print("  !! %s (%s as %s)" % (why, res,
                          "white" if a_is_white else "black"))
                done = w + d + l
                score = w + 0.5 * d
                e, m = elo(score, done)
                print("  %3d games  +%d =%d -%d   %+.0f Elo +/- %.0f   (%.0fs)"
                      % (done, w, d, l, e, m, time.time() - t0), flush=True)
    finally:
        A.close(); B.close()
    return w, d, l


if __name__ == "__main__":
    import argparse
    p = argparse.ArgumentParser()
    p.add_argument("--a", default="engine"); p.add_argument("--amod", default="agent")
    p.add_argument("--b", default="baseline"); p.add_argument("--bmod", default="agent")
    p.add_argument("--pairs", type=int, default=6)
    p.add_argument("--base", type=int, default=10000)
    p.add_argument("--inc", type=int, default=100)
    a = p.parse_args()
    print("match: %s/%s vs %s/%s  %d pairs  %dms+%dms"
          % (a.a, a.amod, a.b, a.bmod, a.pairs, a.base, a.inc), flush=True)
    run(a.a, a.amod, a.b, a.bmod, a.pairs, a.base, a.inc)
