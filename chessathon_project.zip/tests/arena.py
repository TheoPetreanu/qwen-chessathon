"""Match harness that reproduces the competition conditions.

120 s + 0.5 s per side, one process per agent (so state persists between a
side's own moves), clock enforced, illegal moves and crashes scored as losses.
Games start from a supplied position; the competition uses curated near-equal
starts, so the default suite is a set of balanced openings rather than the
initial position only.
"""
import sys, os, time, subprocess, json, random
import chess

BASE_MS = 120_000
INC_MS = 500



class Engine:
    """Runs an agent in its own process, exactly as the competition does."""

    def __init__(self, module_dir, module_name, python=sys.executable):
        self.name = module_name
        self.proc = subprocess.Popen(
            [python, "-u", os.path.join(os.path.dirname(__file__), "worker.py"),
             module_dir, module_name],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE,
            stderr=subprocess.PIPE, text=True, bufsize=1)
        line = self.proc.stdout.readline().strip()
        if line != "ready":
            err = self.proc.stderr.read()
            raise RuntimeError("init failed for %s: %s\n%s" % (module_name, line, err))

    def move(self, fen, ms_left):
        self.proc.stdin.write(json.dumps({"fen": fen, "ms": ms_left}) + "\n")
        self.proc.stdin.flush()
        line = self.proc.stdout.readline()
        if not line:
            raise RuntimeError("%s died" % self.name)
        return json.loads(line)

    def close(self):
        try:
            self.proc.stdin.write("quit\n")
            self.proc.stdin.flush()
            self.proc.wait(timeout=5)
        except Exception:
            self.proc.kill()


def play(white, black, start_fen, max_plies=600, verbose=False,
         base_ms=BASE_MS, inc_ms=INC_MS):
    board = chess.Board(start_fen)
    clock = {chess.WHITE: base_ms, chess.BLACK: base_ms}
    engines = {chess.WHITE: white, chess.BLACK: black}
    reason = ""
    while True:
        if board.is_game_over(claim_draw=True) or board.ply() >= max_plies:
            break
        side = board.turn
        eng = engines[side]
        t0 = time.time()
        try:
            resp = eng.move(board.fen(), int(clock[side]))
        except Exception as e:
            return ("0-1" if side == chess.WHITE else "1-0"), "crash:%s" % e, board
        elapsed = (time.time() - t0) * 1000.0
        clock[side] -= elapsed
        if clock[side] < 0:
            return ("0-1" if side == chess.WHITE else "1-0"), "flag", board
        clock[side] += inc_ms
        if "error" in resp:
            return ("0-1" if side == chess.WHITE else "1-0"), "crash:%s" % resp["error"], board
        try:
            mv = chess.Move.from_uci(resp["move"])
        except Exception:
            return ("0-1" if side == chess.WHITE else "1-0"), "malformed", board
        if mv not in board.legal_moves:
            return ("0-1" if side == chess.WHITE else "1-0"), "illegal:%s" % resp["move"], board
        board.push(mv)
        if verbose:
            print("  %3d. %-6s  %5.0fms  w=%.1fs b=%.1fs" %
                  (board.fullmove_number, resp["move"], elapsed,
                   clock[chess.WHITE] / 1000, clock[chess.BLACK] / 1000))
    if board.is_game_over(claim_draw=True):
        r = board.result(claim_draw=True)
        reason = "mate" if board.is_checkmate() else "draw"
    else:
        r, reason = "1/2-1/2", "plylimit"
    return r, reason, board
