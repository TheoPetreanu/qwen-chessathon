import sys, time
sys.path.insert(0, 'engine')
t0 = time.time()
import agent
print("init (import + jit + warmup): %.1f s   [budget 90 s]" % agent.INIT_SECONDS)

import chess
for fen, ms in [(chess.STARTING_FEN, 120000),
                ("r1bqkbnr/pppp1ppp/2n5/4p3/2B1P3/5N2/PPPP1PPP/RNBQK2R w KQkq - 4 4", 120000),
                ("8/2p5/3p4/KP5r/1R3p1k/8/4P1P1/8 w - - 0 1", 60000)]:
    t = time.time()
    mv = agent.get_move(fen, ms)
    dt = time.time() - t
    info = agent._INFO
    nodes = int(info[1])
    print("%-46s -> %-6s  %.2fs  depth %d/%d  %d nodes  %.2f Mnps  score %d"
          % (fen[:44], mv, dt, int(info[6]), int(info[3]), nodes,
             nodes / max(dt, 1e-9) / 1e6, int(info[5])))
    assert chess.Move.from_uci(mv) in chess.Board(fen).legal_moves, "ILLEGAL MOVE"
print("all moves legal")
