"""Randomised validation.

Plays thousands of random games. At every position it checks:
  1. our legal move list == python-chess's legal move list
  2. make/unmake restores bitboards, mailbox, occupancy and state exactly
  3. the incrementally updated zobrist key == the key recomputed from scratch

Perft proves the counts; this proves the moves themselves, the undo path and
the hash, which is what the transposition table depends on.
"""
import sys, random
sys.path.insert(0, 'engine')
import numpy as np, chess

from ca_movegen import gen_moves, make_move, unmake_move, compute_hash
from ca_position import new_position, new_stacks, from_fen, move_to_uci

bb, occ, mail, st, hsh = new_position()
undo, undo_h, moves = new_stacks()


def check(board, ply):
    from_fen(board.fen(), bb, occ, mail, st, hsh)
    n = gen_moves(bb, occ, mail, st, moves[ply], False)
    ours = sorted(move_to_uci(moves[ply][i]) for i in range(n))
    theirs = sorted(m.uci() for m in board.legal_moves)
    if ours != theirs:
        return "movelist mismatch\n  fen %s\n  missing %s\n  extra %s" % (
            board.fen(), sorted(set(theirs) - set(ours)), sorted(set(ours) - set(theirs)))

    snap = (bb.copy(), occ.copy(), mail.copy(), st.copy(), hsh.copy())
    for i in range(n):
        m = moves[ply][i]
        make_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m)
        if hsh[0] != compute_hash(bb, st):
            return "zobrist drift after %s from %s" % (move_to_uci(m), board.fen())
        if (occ[0] | occ[1]) != occ[2] or np.bitwise_or.reduce(bb[:6]) != occ[0] \
                or np.bitwise_or.reduce(bb[6:]) != occ[1]:
            return "occupancy desync after %s from %s" % (move_to_uci(m), board.fen())
        unmake_move(bb, occ, mail, st, hsh, undo, undo_h, ply, m)
        if not (np.array_equal(bb, snap[0]) and np.array_equal(occ, snap[1])
                and np.array_equal(mail, snap[2]) and np.array_equal(st, snap[3])
                and np.array_equal(hsh, snap[4])):
            return "unmake did not restore after %s from %s" % (move_to_uci(m), board.fen())
    return None


def main(games=1500, seed=7):
    rng = random.Random(seed)
    positions = 0
    for g in range(games):
        board = chess.Board()
        ply = 0
        while not board.is_game_over(claim_draw=False) and ply < 140:
            err = check(board, min(ply, 100))
            positions += 1
            if err:
                print("FAIL at game %d ply %d:\n%s" % (g, ply, err))
                return 1
            board.push(rng.choice(list(board.legal_moves)))
            ply += 1
    print("OK: %d positions validated across %d random games "
          "(move lists, make/unmake, occupancy, zobrist)" % (positions, games))
    return 0


if __name__ == "__main__":
    sys.exit(main())
